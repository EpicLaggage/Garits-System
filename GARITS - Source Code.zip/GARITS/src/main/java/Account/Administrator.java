/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Account;

/**
 *
 * @author jorda
 */
public class Administrator extends Staff {
    public Administrator(String user_name, String password, String role, String name) {
        super(user_name, password, role, name);
    }
    
    
    
}
