package Account;

public interface DiscountPlan {

	void Calculate();

	/**
	 * 
	 * @param percentage
	 */
	void setPercentage(float percentage);

}