/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Account;

/**
 *
 * @author jorda
 */
public class Foreperson extends Mechanic {
    
    public Foreperson(String user_name, String password, String role, String name, float hourly_rate) {
        super(user_name, password, role, name, hourly_rate);
    }
    
    
    
}
