package Core;

import Processing.*;
import StockControl.*;

public class GUIGateway {

	public GUIGateway() {
		// TODO - implement GUIGateway.GUIGateway
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param pass
	 */
	public void login(String id, char pass) {
		// TODO - implement GUIGateway.login
		throw new UnsupportedOperationException();
	}

	public void CheckRole() {
		// TODO - implement GUIGateway.CheckRole
		throw new UnsupportedOperationException();
	}

	public void ReorderStock() {
		// TODO - implement GUIGateway.ReorderStock
		throw new UnsupportedOperationException();
	}

	public void PrintReminders() {
		// TODO - implement GUIGateway.PrintReminders
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param n
	 */
	public void PrintRemindersByName(String n) {
		// TODO - implement GUIGateway.PrintRemindersByName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param job
	 */
	public void AddJobs(Job job) {
		// TODO - implement GUIGateway.AddJobs
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param no
	 * @param status
	 */
	public void ChangeJobStatus(int no, String status) {
		// TODO - implement GUIGateway.ChangeJobStatus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param num
	 */
	public Job SearchForJobByCarNum(int num) {
		// TODO - implement GUIGateway.SearchForJobByCarNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param no
	 */
	public Job SearchForJobByJobNum(int no) {
		// TODO - implement GUIGateway.SearchForJobByJobNum
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 */
	public Part FindPartsByName(String name) {
		// TODO - implement GUIGateway.FindPartsByName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param part
	 */
	public void AddPart(Part part) {
		// TODO - implement GUIGateway.AddPart
		throw new UnsupportedOperationException();
	}

	public void NumOfVehiclesPerMonth() {
		// TODO - implement GUIGateway.NumOfVehiclesPerMonth
		throw new UnsupportedOperationException();
	}

	public void NumOfVehicles() {
		// TODO - implement GUIGateway.NumOfVehicles
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param type
	 */
	public void NumOfVehiclesByJobType(String type) {
		// TODO - implement GUIGateway.NumOfVehiclesByJobType
		throw new UnsupportedOperationException();
	}

	public void GenerateCustomers() {
		// TODO - implement GUIGateway.GenerateCustomers
		throw new UnsupportedOperationException();
	}

	public void AverageTiimePerJob() {
		// TODO - implement GUIGateway.AverageTiimePerJob
		throw new UnsupportedOperationException();
	}

	public void GenerateStock() {
		// TODO - implement GUIGateway.GenerateStock
		throw new UnsupportedOperationException();
	}

}