package Processing;

import java.util.Date;

public class Card {

	private Date expiry_date;
	private String type;
	private int last4Digits;

	public Card Card() {
		// TODO - implement Card.Card
		throw new UnsupportedOperationException();
	}

}