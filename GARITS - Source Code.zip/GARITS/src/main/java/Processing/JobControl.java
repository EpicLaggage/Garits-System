package Processing;

public class JobControl {

	private Job jobs;

	public JobControl JobControl() {
		// TODO - implement JobControl.JobControl
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param job
	 */
	public void AddJobs(Job job) {
		// TODO - implement JobControl.AddJobs
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param no
	 * @param status
	 */
	public void ChangeJobStatus(int no, String status) {
		// TODO - implement JobControl.ChangeJobStatus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param num
	 */
	public void SearchForJobByCarNum(int num) {
		// TODO - implement JobControl.SearchForJobByCarNum
		throw new UnsupportedOperationException();
	}

	public void PrintReminder() {
		// TODO - implement JobControl.PrintReminder
		throw new UnsupportedOperationException();
	}

	public void DisplayReminder() {
		// TODO - implement JobControl.DisplayReminder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param job_no
	 */
	public void GenerateInvoice(int job_no) {
		// TODO - implement JobControl.GenerateInvoice
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param job_no
	 */
	public void DisplayInvoice(int job_no) {
		// TODO - implement JobControl.DisplayInvoice
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param job_no
	 */
	public void CreateJobSheet(int job_no) {
		// TODO - implement JobControl.CreateJobSheet
		throw new UnsupportedOperationException();
	}

}