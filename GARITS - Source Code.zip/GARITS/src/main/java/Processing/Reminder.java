package Processing;

public class Reminder {

	private String[] description;
	private boolean sent;

	public Reminder Reminder() {
		// TODO - implement Reminder.Reminder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param no
	 */
	public Reminder Reminder(int no) {
		// TODO - implement Reminder.Reminder
		throw new UnsupportedOperationException();
	}

	public String[] getDescription() {
		return this.description;
	}

	/**
	 * 
	 * @param description
	 */
	public void setDescription(String[] description) {
		this.description = description;
	}

	public boolean getSent() {
		return this.sent;
	}

	/**
	 * 
	 * @param sent
	 */
	public void setSent(boolean sent) {
		this.sent = sent;
	}

}