package StockControl;

public class Stock {

	private Part parts;

	public Stock() {
		// TODO - implement Stock.Stock
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 */
	public Part FindPartsByName(String name) {
		// TODO - implement Stock.FindPartsByName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param part
	 */
	public void AddPart(Part part) {
		// TODO - implement Stock.AddPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param part
	 */
	public void RemovePart(Part part) {
		// TODO - implement Stock.RemovePart
		throw new UnsupportedOperationException();
	}

}